<?php
session_start();

// Proses checkout sederhana: hanya kosongkan keranjang
unset($_SESSION['cart']); 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Checkout Berhasil - Tokoku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h1 style="color: #28a745;">Terima Kasih!</h1>
        <p style="text-align: center;">Pesanan Anda telah berhasil dibuat.</p>
        <a href="index.php" class="btn">Kembali ke Toko</a>
    </div>
</body>
</html>