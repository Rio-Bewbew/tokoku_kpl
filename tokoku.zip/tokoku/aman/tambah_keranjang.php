<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = (int)$_POST['product_id'];

    // Inisialisasi keranjang jika belum ada
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Tambah kuantitas jika produk sudah ada di keranjang, atau tambahkan produk baru
    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]++; // Tambah kuantitas
    } else {
        $_SESSION['cart'][$product_id] = 1; // Produk baru, kuantitas 1
    }
}

// Redirect kembali ke halaman keranjang
header('Location: keranjang.php');
exit;