<?php
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: index.php');
    exit;
}

$error_message = '';
$success_message = '';

if (isset($_GET['status']) && $_GET['status'] === 'sukses') {
    $success_message = 'Registrasi berhasil! Silakan login.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    $username = $_POST['username'];
    $password = $_POST['password'];

    // --- CARA LOGIN YANG AMAN (MENGGUNAKAN PREPARED STATEMENTS) ---
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    // --- BATAS KODE AMAN ---

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verifikasi password yang di-hash dengan aman
        if (password_verify($password, $user['password'])) {
            $_SESSION['loggedin'] = true;
            $_SESSION['nama'] = $user['nama_lengkap'];
            $_SESSION['role'] = $user['role'];
            header('Location: index.php');
            exit;
        }
    }
    
    // Jika username tidak ditemukan atau password salah
    $error_message = "Username atau password salah!";
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Tokoku (AMAN)</title>
    
    <link rel="stylesheet" href="../style.css"> 
</head>
<body>
    <div class="login-container">
        <h1>Login Akun (Secure)</h1>

        <?php if (!empty($error_message)): ?>
            <div class="alert-error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <div class="alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <form action="login.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <p style="text-align: center; margin-top: 20px;">
            Belum punya akun? <a href="register.php">Daftar di sini</a>
        </p>
    </div>
</body>
</html>