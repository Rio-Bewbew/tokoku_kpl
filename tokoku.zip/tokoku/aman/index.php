<?php
session_start();

// --- Koneksi Database ---
$db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) { die("Koneksi gagal: " . $conn->connect_error); }

// Ambil semua produk dari database
$result = $conn->query("SELECT * FROM products ORDER BY id DESC");
$products = $result->fetch_all(MYSQLI_ASSOC);

// Hitung jumlah item di keranjang
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $quantity) {
        $cart_count += $quantity;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tokoku - Belanja Online Terpercaya</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
    <header class="header">
        <div class="container header-container">
            <a href="index.php" class="logo">Tokoku</a>
            
            <div class="search-bar">
                <input type="text" placeholder="Cari produk di Tokoku...">
                <button><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
            
            <nav class="nav-links">
                <a href="keranjang.php" class="cart-link">
                    <i class="fa-solid fa-cart-shopping"></i>
                    <?php if ($cart_count > 0): ?>
                        <span class="cart-badge"><?php echo $cart_count; ?></span>
                    <?php endif; ?>
                </a>
                <div class="divider"></div>

                <?php if (isset($_SESSION['loggedin'])): ?>
                    <div class="user-dropdown">
                        <button class="nav-button user-button">
                            <i class="fa-solid fa-user"></i> Halo, <?php echo strtok($_SESSION['nama'], " "); ?>
                        </button>
                        <div class="dropdown-menu">
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <a href="admin/index.php">Admin Panel</a>
                            <?php endif; ?>
                            <a href="#">Profil Saya</a>
                            <a href="#">Pesanan</a>
                            <a href="logout.php">Logout</a>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="nav-button">Login</a>
                    <a href="register.php" class="nav-button primary">Daftar</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <h1>Promo Gajian, Diskon Gila-Gilaan!</h1>
                <p>Belanja lebih hemat dengan diskon hingga 70% untuk semua kategori.</p>
            </div>
        </section>

        <section class="categories-section container">
            <h2>Kategori Pilihan</h2>
            <div class="category-grid">
                <a href="#" class="category-card"><i class="fa-solid fa-shirt"></i><span>Pakaian Pria</span></a>
                <a href="#" class="category-card"><i class="fa-solid fa-vest-patches"></i><span>Pakaian Wanita</span></a>
                <a href="#" class="category-card"><i class="fa-solid fa-mobile-screen-button"></i><span>Elektronik</span></a>
                <a href="#" class="category-card"><i class="fa-solid fa-house-chimney"></i><span>Rumah Tangga</span></a>
                <a href="#" class="category-card"><i class="fa-solid fa-baby"></i><span>Ibu & Anak</span></a>
                <a href="#" class="category-card"><i class="fa-solid fa-ellipsis"></i><span>Lainnya</span></a>
            </div>
        </section>

        <section class="product-section container">
            <h2>Produk Terbaru</h2>
            <div class="product-grid">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <div class="product-image-container">
                            <img src="../images/<?php echo htmlspecialchars($product['image']); ?>" ... >
                        </div>
                        <div class="product-info">
                            <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-price">Rp <?php echo number_format($product['price'], 0, ',', '.'); ?></p>
                            <form action="tambah_keranjang.php" method="post" class="add-to-cart-form">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" class="btn"><i class="fa-solid fa-cart-plus"></i> Tambah</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Tokoku. Hak Cipta Dilindungi.</p>
        </div>
    </footer>
</body>
</html>