<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    echo "Akses Ditolak.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];

    // Kode untuk upload gambar akan ditambahkan nanti, untuk sekarang pakai placeholder
    $image = 'product_placeholder.png'; 

    $stmt = $conn->prepare("INSERT INTO products (name, description, price, image) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssds", $name, $desc, $price, $image);
    $stmt->execute();

    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk Baru</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<main class="container">
    <h1>Tambah Produk Baru</h1>
    <form method="post" class="login-container" style="max-width: 600px;">
        <div class="form-group">
            <label>Nama Produk</label>
            <input type="text" name="name" required>
        </div>
        <div class="form-group">
            <label>Deskripsi</label>
            <textarea name="description" required rows="4"></textarea>
        </div>
        <div class="form-group">
            <label>Harga</label>
            <input type="number" name="price" step="1000" required>
        </div>
        <button type="submit" class="btn">Simpan Produk</button>
    </form>
</main>
</body>
</html>