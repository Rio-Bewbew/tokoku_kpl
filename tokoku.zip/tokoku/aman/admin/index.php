<?php
session_start();
// Gerbang Keamanan: Hanya admin yang boleh mengakses halaman ini
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    echo "Akses Ditolak. Anda bukan admin.";
    exit;
}

// Koneksi ke database
$db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Kelola Produk</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
<main class="container">
    <h1>Panel Admin - Kelola Produk</h1>
    <a href="tambah.php" class="nav-button primary" style="text-decoration:none; display:inline-block; margin-bottom:20px;">+ Tambah Produk Baru</a>
    <table class="cart-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Gambar</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $p): ?>
            <tr>
                <td><?php echo $p['id']; ?></td>
                <td><img src="../<?php echo htmlspecialchars($p['image']); ?>" width="50"></td>
                <td><?php echo htmlspecialchars($p['name']); ?></td>
                <td>Rp <?php echo number_format($p['price'], 0, ',', '.'); ?></td>
                <td>
                    <a href="edit.php?id=<?php echo $p['id']; ?>">Edit</a> | 
                    <a href="hapus.php?id=<?php echo $p['id']; ?>" onclick="return confirm('Anda yakin ingin menghapus produk ini?')">Hapus</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>
</body>
</html>