<?php
session_start();
// Gerbang Keamanan: Hanya admin yang boleh mengakses halaman ini
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    echo "Akses Ditolak. Anda bukan admin.";
    exit;
}

// Koneksi ke database
$db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

$products = $conn->query("SELECT * FROM products ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Kelola Produk</title>
    <!-- Path CSS yang benar (keluar dua folder) -->
    <link rel="stylesheet" href="../../style.css"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>
<body>
    <header class="header">
        <div class="container header-container">
            <a href="../index.php" class="logo">Tokoku <span class="admin-tag">Admin</span></a>
            <nav class="nav-links">
                <a href="../index.php" class="nav-button">Kembali ke Toko</a>
                <a href="../logout.php" class="nav-button primary">Logout</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="admin-container">
            <div class="admin-header">
                <h1>Kelola Produk</h1>
                <a href="tambah.php" class="btn"><i class="fa-solid fa-plus"></i> Tambah Produk Baru</a>
            </div>
            
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Gambar</th>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="5" style="text-align:center;">Belum ada produk.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $p): ?>
                        <tr>
                            <td><?php echo $p['id']; ?></td>
                            <td>
                                <!-- PASTIKAN CLASS "table-img" ADA DI SINI -->
                                <img src="../../images/<?php echo htmlspecialchars($p['image']); ?>" class="table-img" alt="<?php echo htmlspecialchars($p['name']); ?>">
                            </td>
                            <td class="product-name"><?php echo htmlspecialchars($p['name']); ?></td>
                            <td>Rp <?php echo number_format($p['price'], 0, ',', '.'); ?></td>
                            <td>
                                <a href="edit.php?id=<?php echo $p['id']; ?>" class="action-link edit"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                                <a href="hapus.php?id=<?php echo $p['id']; ?>" class="action-link delete" onclick="return confirm('Anda yakin ingin menghapus produk ini?')"><i class="fa-solid fa-trash"></i> Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
