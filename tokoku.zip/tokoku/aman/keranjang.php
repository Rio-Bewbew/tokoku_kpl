<?php
session_start();

// --- Koneksi Database ---
$db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

$cart_items = [];
$total_price = 0;

if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $product_ids = array_keys($_SESSION['cart']);
    $ids_string = implode(',', $product_ids);

    // Ambil data produk yang ada di keranjang
    // PENTING: Mulai sekarang kita gunakan kode yang aman (Prepared Statements)
    $stmt = $conn->prepare("SELECT * FROM products WHERE id IN ($ids_string)");
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($product = $result->fetch_assoc()) {
        $quantity = $_SESSION['cart'][$product['id']];
        $cart_items[] = [
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => $quantity
        ];
        $total_price += $product['price'] * $quantity;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja - Tokoku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="top-bar">
        <div class="container">
            <a href="index.php" class="logo">Tokoku</a>
            <nav><a href="index.php">Lanjut Belanja</a></nav>
        </div>
    </header>

    <main class="container">
        <h1>Keranjang Belanja Anda</h1>
        <?php if (empty($cart_items)): ?>
            <p>Keranjang Anda masih kosong.</p>
        <?php else: ?>
            <table class="cart-table">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Kuantitas</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td>
                                <img src="<?php echo htmlspecialchars($item['image']); ?>" width="50" alt="">
                                <?php echo htmlspecialchars($item['name']); ?>
                            </td>
                            <td>Rp <?php echo number_format($item['price'], 0, ',', '.'); ?></td>
                            <td><?php echo $item['quantity']; ?></td>
                            <td>Rp <?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="cart-total">
                <h3>Total Belanja: Rp <?php echo number_format($total_price, 0, ',', '.'); ?></h3>
                <a href="checkout.php" class="btn">Lanjut ke Checkout</a>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>