<?php
// File: dashboard.php
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h1>Selamat Datang!</h1>
        <p style="text-align: center; font-size: 18px;">Halo, <strong><?php echo htmlspecialchars($_SESSION['nama']); ?></strong>!</p>
        <p style="text-align: center;">Anda telah berhasil login ke dashboard.</p>
        <a href="logout.php" class="btn" style="text-decoration: none; text-align: center; display: block; background-color: #6c757d;">Logout</a>
    </div>
</body>
</html>