<?php
$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // --- Koneksi Database ---
    $db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    $nama_lengkap = trim($_POST['nama_lengkap']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Validasi dasar
    if (empty($nama_lengkap) || empty($username) || empty($password)) {
        $error_message = 'Semua kolom harus diisi!';
    } else {
        // Cek apakah username sudah ada (MENGGUNAKAN PREPARED STATEMENT AGAR AMAN)
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = 'Username sudah digunakan, silakan pilih yang lain.';
        } else {
            // Hash password sebelum disimpan ke database (SANGAT PENTING UNTUK KEAMANAN)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Masukkan pengguna baru ke database (MENGGUNAKAN PREPARED STATEMENT AGAR AMAN)
            $stmt_insert = $conn->prepare("INSERT INTO users (nama_lengkap, username, password) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("sss", $nama_lengkap, $username, $hashed_password);

            if ($stmt_insert->execute()) {
                // Redirect ke halaman login dengan pesan sukses
                header('Location: login.php?status=sukses');
                exit;
            } else {
                $error_message = 'Registrasi gagal, silakan coba lagi.';
            }
            $stmt_insert->close();
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Akun - Tokoku</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="login-container">
        <h1>Buat Akun Baru</h1>

        <?php if (!empty($error_message)): ?>
            <div class="alert-error"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form action="register.php" method="post">
            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap</label>
                <input type="text" id="nama_lengkap" name="nama_lengkap" required>
            </div>
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="btn">Daftar</button>
        </form>
        <p style="text-align: center; margin-top: 20px;">
            Sudah punya akun? <a href="login.php">Login di sini</a>
        </p>
    </div>
</body>
</html>