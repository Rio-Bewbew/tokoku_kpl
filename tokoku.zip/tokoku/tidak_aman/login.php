<?php
session_start();

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    header('Location: index.php');
    exit;
}

$error_message = '';
$success_message = '';

if (isset($_GET['status']) && $_GET['status'] === 'sukses') {
    $success_message = 'Registrasi berhasil! Silakan login.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = 'localhost'; $db_user = 'root'; $db_pass = ''; $db_name = 'tokoku_db';
    $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

    $username = $_POST['username'];
    $password = $_POST['password'];

    // !!! INI ADALAH BAGIAN KUNCI YANG MEMBUATNYA SANGAT RENTAN !!!
    // Username DAN Password dari pengguna langsung digabungkan ke dalam query.
    // Ini adalah bentuk paling dasar dan paling berbahaya dari celah SQL Injection.
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Karena query di atas sudah berhasil, kita bisa langsung memberikan akses.
        $_SESSION['loggedin'] = true;
        $_SESSION['nama'] = $user['nama_lengkap'];
        $_SESSION['role'] = $user['role'];
        header('Location: index.php');
        exit;
    }
    
    $error_message = "Username atau password salah!";
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Tokoku (TIDAK AMAN)</title>
    <link rel="stylesheet" href="../style.css"> 
</head>
<body>
    <div class="login-container">
        <h1>Login Akun (Vulnerable)</h1>

        <?php if (!empty($error_message)): ?>
            <div class="alert-error"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <div class="alert-success"><?php echo $success_message; ?></div>
        <?php endif; ?>

        <form action="login.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password">
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
        <p style="text-align: center; margin-top: 20px;">
            Belum punya akun? <a href="register.php">Daftar di sini</a>
        </p>
    </div>
</body>
</html>